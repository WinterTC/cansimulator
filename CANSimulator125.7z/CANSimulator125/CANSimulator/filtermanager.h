#ifndef FILTERMANAGER_H
#define FILTERMANAGER_H

#include <QMainWindow>
#include "measuresetup.h"
#include "ui_filtermanager.h"
#include <QCheckBox>
#include <QComboBox>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include "filterdialoggetid.h"
#include <QHeaderView>
class FilterManagerWindow : public  QMainWindow, Ui_FilterManager
{
    Q_OBJECT

public:
    explicit FilterManagerWindow(QWidget *parent = 0);
    ~FilterManagerWindow();
    bool count = true;
protected:
    void closeEvent(QCloseEvent* event);
public slots:
    void on_buttonRawData_click();
    void on_buttonOk_accept();
    void on_buttonCancel_reject();
    void on_buttonHelp_click();
   void slotGetID(int sID,int eID);
   void slotRemoveRow();
   void sectionDoubleClickedSlot(int index);
   void sectionClickedSlot(int index);
private:

   QLabel *LabelEnter;
   QLabel *LabelStartID;
   QLabel *LabelEndID;
   QLabel *LabelSpinbox;
   QLineEdit *LineEditStartID;
   QLineEdit *LineEditEndID;
   QComboBox *ComboBoxBussystem;
   QPushButton *buttonOk;
   QPushButton *buttonCancel;
   QStringList m1_TableHeader;
   DialogGetID *m_GetIdDialog;
   QHeaderView *m_HeaderView;

};

class FilterNodeManager{

};

#endif // FILTERMANAGER_H
