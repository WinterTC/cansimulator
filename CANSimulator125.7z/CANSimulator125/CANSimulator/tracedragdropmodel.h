#ifndef TRACEDRAGDROPMODEL_H
#define TRACEDRAGDROPMODEL_H
#include <QMimeData>
#include "tracetreemodel.h"
#include <QStringList>
class TraceDragDropModel: public TraceTreeModel
{
    Q_OBJECT
public:
    TraceDragDropModel(const QStringList &strings, QObject *parent = 0);

    Qt::ItemFlags flags(const QModelIndex &index) const;

    bool dropMimeData(const QMimeData *data, Qt::DropAction action,
                      int row, int column, const QModelIndex &parent);
    QMimeData *mimeData(const QModelIndexList &indexes) const;
    QStringList mimeTypes() const;
    Qt::DropActions supportedDropActions() const;
    TraceDragDropModel *drag;

};

#endif // TRACEDRAGDROPMODEL_H
