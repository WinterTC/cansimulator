/********************************************************************************
** Form generated from reading UI file 'hardwareinterface.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HARDWAREINTERFACE_H
#define UI_HARDWAREINTERFACE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_HardwareInterface
{
public:
    QFormLayout *formLayout;
    QGridLayout *gridLayout_3;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer_2;
    QGroupBox *GroupBoxChannel;
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QPushButton *ButtonCAN1;
    QPushButton *ButtonCAN2;
    QSpacerItem *verticalSpacer;
    QStackedWidget *StackCAN;
    QWidget *m_pageMain;
    QWidget *m_pageCAN1;
    QGroupBox *m_CAN1group;
    QWidget *page_2;
    QWidget *m_pageCAN2;
    QGroupBox *m_CAN2group;
    QGridLayout *gridLayout_5;
    QSpacerItem *horizontalSpacer_2;
    QGridLayout *gridLayout_4;
    QPushButton *HelpButton;
    QPushButton *CancelButton;
    QPushButton *OkButton;

    void setupUi(QDialog *HardwareInterface)
    {
        if (HardwareInterface->objectName().isEmpty())
            HardwareInterface->setObjectName(QStringLiteral("HardwareInterface"));
        HardwareInterface->resize(422, 158);
        formLayout = new QFormLayout(HardwareInterface);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        gridLayout_3 = new QGridLayout();
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        horizontalSpacer = new QSpacerItem(28, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer, 0, 0, 1, 1);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalSpacer_2 = new QSpacerItem(20, 78, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        GroupBoxChannel = new QGroupBox(HardwareInterface);
        GroupBoxChannel->setObjectName(QStringLiteral("GroupBoxChannel"));
        gridLayout_2 = new QGridLayout(GroupBoxChannel);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(10);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        ButtonCAN1 = new QPushButton(GroupBoxChannel);
        ButtonCAN1->setObjectName(QStringLiteral("ButtonCAN1"));
        ButtonCAN1->setIconSize(QSize(16, 16));

        gridLayout->addWidget(ButtonCAN1, 0, 0, 1, 1);

        ButtonCAN2 = new QPushButton(GroupBoxChannel);
        ButtonCAN2->setObjectName(QStringLiteral("ButtonCAN2"));

        gridLayout->addWidget(ButtonCAN2, 1, 0, 1, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 1);


        verticalLayout->addWidget(GroupBoxChannel);

        verticalSpacer = new QSpacerItem(20, 98, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        gridLayout_3->addLayout(verticalLayout, 0, 1, 1, 1);


        formLayout->setLayout(0, QFormLayout::LabelRole, gridLayout_3);

        StackCAN = new QStackedWidget(HardwareInterface);
        StackCAN->setObjectName(QStringLiteral("StackCAN"));
        m_pageMain = new QWidget();
        m_pageMain->setObjectName(QStringLiteral("m_pageMain"));
        m_pageCAN1 = new QWidget(m_pageMain);
        m_pageCAN1->setObjectName(QStringLiteral("m_pageCAN1"));
        m_pageCAN1->setGeometry(QRect(0, 10, 251, 261));
        m_CAN1group = new QGroupBox(m_pageCAN1);
        m_CAN1group->setObjectName(QStringLiteral("m_CAN1group"));
        m_CAN1group->setGeometry(QRect(0, 0, 241, 251));
        StackCAN->addWidget(m_pageMain);
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        m_pageCAN2 = new QWidget(page_2);
        m_pageCAN2->setObjectName(QStringLiteral("m_pageCAN2"));
        m_pageCAN2->setGeometry(QRect(0, 10, 251, 261));
        m_CAN2group = new QGroupBox(m_pageCAN2);
        m_CAN2group->setObjectName(QStringLiteral("m_CAN2group"));
        m_CAN2group->setGeometry(QRect(0, 0, 241, 261));
        StackCAN->addWidget(page_2);

        formLayout->setWidget(0, QFormLayout::FieldRole, StackCAN);

        gridLayout_5 = new QGridLayout();
        gridLayout_5->setObjectName(QStringLiteral("gridLayout_5"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_5->addItem(horizontalSpacer_2, 0, 0, 1, 1);

        gridLayout_4 = new QGridLayout();
        gridLayout_4->setObjectName(QStringLiteral("gridLayout_4"));
        HelpButton = new QPushButton(HardwareInterface);
        HelpButton->setObjectName(QStringLiteral("HelpButton"));

        gridLayout_4->addWidget(HelpButton, 0, 2, 1, 1);

        CancelButton = new QPushButton(HardwareInterface);
        CancelButton->setObjectName(QStringLiteral("CancelButton"));

        gridLayout_4->addWidget(CancelButton, 0, 1, 1, 1);

        OkButton = new QPushButton(HardwareInterface);
        OkButton->setObjectName(QStringLiteral("OkButton"));

        gridLayout_4->addWidget(OkButton, 0, 0, 1, 1);


        gridLayout_5->addLayout(gridLayout_4, 0, 1, 1, 1);


        formLayout->setLayout(1, QFormLayout::SpanningRole, gridLayout_5);


        retranslateUi(HardwareInterface);

        StackCAN->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(HardwareInterface);
    } // setupUi

    void retranslateUi(QDialog *HardwareInterface)
    {
        HardwareInterface->setWindowTitle(QApplication::translate("HardwareInterface", "Dialog", Q_NULLPTR));
        GroupBoxChannel->setTitle(QApplication::translate("HardwareInterface", "Channel", Q_NULLPTR));
        ButtonCAN1->setText(QApplication::translate("HardwareInterface", "CAN 1", Q_NULLPTR));
        ButtonCAN2->setText(QApplication::translate("HardwareInterface", "CAN 2", Q_NULLPTR));
        m_CAN1group->setTitle(QApplication::translate("HardwareInterface", "CAN Channel 1", Q_NULLPTR));
        m_CAN2group->setTitle(QApplication::translate("HardwareInterface", "CAN Channel 2", Q_NULLPTR));
        HelpButton->setText(QApplication::translate("HardwareInterface", "Help", Q_NULLPTR));
        CancelButton->setText(QApplication::translate("HardwareInterface", "Cancel", Q_NULLPTR));
        OkButton->setText(QApplication::translate("HardwareInterface", "OK", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class HardwareInterface: public Ui_HardwareInterface {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HARDWAREINTERFACE_H
