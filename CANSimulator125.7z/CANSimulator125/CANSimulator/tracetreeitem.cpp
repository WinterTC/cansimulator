#include "tracetreeitem.h"
#include <QStringList>

TraceTreeItem::TraceTreeItem(const QList<QVariant> &data, TraceTreeItem *parent)
{
    parentItem = parent;
    itemData = data;
}

TraceTreeItem::~TraceTreeItem()
{
    qDeleteAll(childItems);
}

void TraceTreeItem::appendChild(TraceTreeItem *item)
{
    childItems.append(item);
}

TraceTreeItem *TraceTreeItem::child(int row)
{
    return childItems.value(row);
}

int TraceTreeItem::childCount() const
{
    return childItems.count() ;
}

int TraceTreeItem::columnCount() const
{
    return itemData.count();
}

QVariant TraceTreeItem::data(int column) const
{
    return itemData.value(column);
}

bool TraceTreeItem::insertChild(int row, TraceTreeItem *item)
{
    if (row < 0 || row > childItems.count())
        return false;

    childItems.insert(row, item);
    return true;
}

TraceTreeItem *TraceTreeItem::parent()
{
    return parentItem;
}

bool TraceTreeItem::removeChild(int row)
{
    if (row < 0 || row >= childItems.count())
        return false;

    delete childItems.takeAt(row);
    return true;
}

int TraceTreeItem::row() const
{
    if (parentItem)
        return parentItem->childItems.indexOf(const_cast<TraceTreeItem*>(this));

    return 0;
}

bool TraceTreeItem::setData(int column, const QVariant &data)
{
    if (column < 0 || column >= itemData.count())
        return false;

    itemData.replace(column, data);
    return true;
}
