#ifndef DBMANAGER_H
#define DBMANAGER_H
#include <QString>
#include <QStringList>
#include <CANDefines.h>
class DbManager
{
public:
    DbManager();
    ~DbManager();
    void addAssosiateDb(QString path);
    void removeAssosiateDb(QString path);
private:
    QStringList m_DbPaths;
    QVector<CANMessage> m_CANMsgs;
};

#endif // DBMANAGER_H
