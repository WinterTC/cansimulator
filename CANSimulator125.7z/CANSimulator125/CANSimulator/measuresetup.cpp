#include "measuresetup.h"
#include "ui_measuresetup.h"

#include <QDebug>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QPainter>
#include <QPen>
#include <QToolButton>
#include <QPaintEvent>
#include <QJsonDocument>
#include <QPalette>
#include <filtermanager.h>
#include <tracemanager.h>
#include <hardwareinterface.h>

MeasureSetupWidget * widgets[50];

MeasureSetupWindow::MeasureSetupWindow(QWidget *parent, MeasureSetupModel * model) :
    QMainWindow(parent)
{
    setupUi(this);
#if 1
    //QString buttonStyle = "QToolButton{border:none;background-color:rgba(0, 255, 0,100);}"; //background-color:rgba(0, 255, 0,100);
    QString buttonStyle = "QToolButton{border:none;border-image:url(:/icons/node.png);background-color:none;}"; //background-color:rgba(0, 255, 0,100);
    QString buttonStyle1 = "QToolButton{border:none;background-color:none;}";
    activeGridLayout->setSpacing(5);
    int min,max;
    QIcon icon(":/icons/node.png");
    //    min = icon.
    int i=0;
    QWidget * wd = new QWidget();
    wd->setFixedWidth(20);
    wd->setMaximumWidth(50);
    wd->setMaximumHeight(50);
    activeGridLayout->addWidget(wd,10,10);
    activeGridLayout->addWidget(wd,0,0);

    activeGridLayout->setColumnMinimumWidth(10,10);

    widgets[i] = new MeasureSetupWidget(QIcon(""),QString("IG"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(100,50);
    widgets[i]->setMaximumSize(200,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],11,2);
    connect(widgets[i],SIGNAL(clicked()),this,SLOT(findwidgets()));

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/join.PNG"),QString(""),this);//1
    widgets[i]->setStyleSheet(buttonStyle1);
    widgets[i]->setMinimumSize(25,25);
    widgets[i]->setMaximumSize(50,50);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],11,3);
    connect(widgets[i],SIGNAL(clicked()),this,SLOT(slotChangeIcon()));


    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(""),QString("IG"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(100,50);
    widgets[i]->setMaximumSize(200,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],13,2);

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/join.PNG"),QString(""),this);//3
    widgets[i]->setStyleSheet(buttonStyle1);
    widgets[i]->setMinimumSize(25,25);
    widgets[i]->setMaximumSize(50,50);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],13,3);

    activeGridLayout->addWidget(wd,10,4);

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(""),QString("Filter"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(100,50);
    widgets[i]->setMaximumSize(200,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],11,5);
    connect(widgets[i],SIGNAL(clicked()),this,SLOT(slotShowfilter()));

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/join.PNG"),QString(""),this);//5
    widgets[i]->setStyleSheet(buttonStyle1);
    widgets[i]->setMinimumSize(25,25);
    widgets[i]->setMaximumSize(50,50);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],11,6);
    connect(widgets[i],SIGNAL(clicked()),this,SLOT(slotChangeIcon()));

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(""),QString("Filter"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(100,50);
    widgets[i]->setMaximumSize(200,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],13,5);
    connect(widgets[i],SIGNAL(clicked()),this,SLOT(slotShowfilter()));

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/join.PNG"),QString(""),this);//7
    widgets[i]->setStyleSheet(buttonStyle1);
    widgets[i]->setMinimumSize(25,25);
    widgets[i]->setMaximumSize(50,50);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],13,6);

    activeGridLayout->addWidget(wd,10,7);

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/join.PNG"),QString(""),this);//8
    widgets[i]->setStyleSheet(buttonStyle1);
    widgets[i]->setMinimumSize(25,25);
    widgets[i]->setMaximumSize(50,50);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],12,8);

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(""),QString("Filter"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(100,50);
    widgets[i]->setMaximumSize(200,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],12,9);
    connect(widgets[i],SIGNAL(clicked()),this,SLOT(slotShowfilter()));

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/join.PNG"),QString(""),this);//10
    widgets[i]->setStyleSheet(buttonStyle1);
    widgets[i]->setMinimumSize(25,25);
    widgets[i]->setMaximumSize(50,50);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],12,10);

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(""),QString("HARDWARE(Tx/Rx)"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(150,150);
    widgets[i]->setMaximumSize(250,150);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],12,11);
    connect(widgets[i],SIGNAL(clicked()),this,SLOT(slotShowhardware()));

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/join.PNG"),QString(""),this);//12
    widgets[i]->setStyleSheet(buttonStyle1);
    widgets[i]->setMinimumSize(25,25);
    widgets[i]->setMaximumSize(50,50);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],12,12);

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(""),QString("Filter"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(100,50);
    widgets[i]->setMaximumSize(200,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],12,13);
    connect(widgets[i],SIGNAL(clicked()),this,SLOT(slotShowfilter()));

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/join.PNG"),QString(""),this);//14
    widgets[i]->setStyleSheet(buttonStyle1);
    widgets[i]->setMinimumSize(25,25);
    widgets[i]->setMaximumSize(50,50);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],12,14);
    //connect(widgets[i],SIGNAL(clicked()),this

    activeGridLayout->addWidget(wd,10,15);

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/join.PNG"),QString(""),this);//15
    widgets[i]->setStyleSheet(buttonStyle1);
    widgets[i]->setMinimumSize(25,25);
    widgets[i]->setMaximumSize(50,50);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],11,16);

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(""),QString("Filter"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(100,50);
    widgets[i]->setMaximumSize(200,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],11,17);
    connect(widgets[i],SIGNAL(clicked()),this,SLOT(slotShowfilter()));

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/join.PNG"),QString(""),this);//17
    widgets[i]->setStyleSheet(buttonStyle1);
    widgets[i]->setMinimumSize(25,25);
    widgets[i]->setMaximumSize(50,50);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],13,16);

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(""),QString("Filter"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(100,50);
    widgets[i]->setMaximumSize(200,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],13,17);
    connect(widgets[i],SIGNAL(clicked()),this,SLOT(slotShowfilter()));

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/join.PNG"),QString(""),this);//19
    widgets[i]->setStyleSheet(buttonStyle1);
    widgets[i]->setMinimumSize(25,25);
    widgets[i]->setMaximumSize(50,50);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],11,18);

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(""),QString("Trace"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(100,50);
    widgets[i]->setMaximumSize(200,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],11,19);
    connect(widgets[i],SIGNAL(clicked()),this,SLOT(slotShowTrace()));

    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(":/icons/join.PNG"),QString(""),this);//21
    widgets[i]->setStyleSheet(buttonStyle1);
    widgets[i]->setMinimumSize(25,25);
    widgets[i]->setMaximumSize(50,50);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],13,18);


    i++;
    widgets[i] = new MeasureSetupWidget(QIcon(""),QString("View"),this);
    widgets[i]->setStyleSheet(buttonStyle);
    widgets[i]->setMinimumSize(100,50);
    widgets[i]->setMaximumSize(200,100);
    widgets[i]->setIconSize(widgets[i]->size());
    activeGridLayout->addWidget(widgets[i],13,19);

    connect(widgets[i],SIGNAL(clicked()),this,SLOT(findwidgets()));


#endif

}

MeasureSetupWindow::~MeasureSetupWindow()
{
    //    delete ui;
}

void MeasureSetupModel::deleteItemsRecursive(MeasureSetupItemCommon *item)
{
    if(!item) return;
    for (int i=0;i<item->childCount();) {
        deleteItemsRecursive(item->child(i));
    }
    delete item;
}

void MeasureSetupModel::loadConfig(const QString &configPath)
{
    /*read Json file and create measure setup*/
    if(m_rootItem){
        /*delete all items*/
        deleteItemsRecursive(m_rootItem);
        m_rootItem = NULL;
    }
#if 1
    //For testing
    MeasureSetupItemCommon * newItem, *tmpItem;
    m_rootItem = new MeasureSetupItemCommon(NULL,E_MeasureSetupItemType_IG,E_MeasureSetupBranch_IG);
    newItem = new MeasureSetupItemCommon(NULL,E_MeasureSetupItemType_Interface,E_MeasureSetupBranch_Main);
    m_rootItem->addChildren(0,newItem);
    tmpItem = newItem;
    newItem = new MeasureSetupItemCommon(NULL,E_MeasureSetupItemType_Trace,E_MeasureSetupBranch_View);
   // m_rootItem->addChildren(1,newItem);


#else


#endif
}

void MeasureSetupWindow::resizeEvent(QResizeEvent * evt)
{
}

void MeasureSetupWindow::paintEvent(QPaintEvent *evt)
{
    int i = 0;
    activeGridLayout->setSpacing(5);
    widgets[i]->setIconSize(widgets[i]->size());//A0
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//A1
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//A2
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//A3
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//A4
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//A5
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//A6
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//A7
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//B0
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//B1
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//B2
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//B3
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//B4
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//B5
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//B6
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//C0
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//C1
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//C2
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//C3
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//C4
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//C5
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//C6
    i++;
    widgets[i]->setIconSize(widgets[i]->size());//C7

    QPainter  line (this);
    //line.setPen(QColor(Qt::red));
    QPen Linepen(Qt::red);
    Linepen.setWidth(2);
    line.setPen(Linepen);

//    line.drawLine(widgets[0]->pos().x()+widgets[0]->size().width(),
//            widgets[0]->pos().y()+widgets[0]->size().height()/2,
//            widgets[1]->pos().x(),
//            widgets[1]->pos().y()+widgets[1]->size().height()/2
//            );
    QPoint A0(widgets[0]->x()+widgets[0]->width()/2,widgets[0]->y()+widgets[0]->height()/2);
    QPoint A1(widgets[1]->x()+widgets[1]->width()/2,widgets[1]->y()+widgets[1]->height()/2);

    QPoint A2(widgets[2]->x()+widgets[2]->width()/2,widgets[2]->y()+widgets[2]->height()/2);
    QPoint A3(widgets[3]->x()+widgets[3]->width()/2,widgets[3]->y()+widgets[3]->height()/2);

    QPoint A4(widgets[4]->x()+widgets[4]->width()/2,widgets[4]->y()+widgets[4]->height()/2);
    QPoint A5(widgets[5]->x()+widgets[5]->width()/2,widgets[5]->y()+widgets[5]->height()/2);

    QPoint A6(widgets[6]->x()+widgets[6]->width()/2,widgets[6]->y()+widgets[6]->height()/2);
    QPoint A7(widgets[7]->x()+widgets[7]->width()/2,widgets[7]->y()+widgets[7]->height()/2);

    QPoint Ax((A5+A7)/2);

    QPoint B0(widgets[8]->x()+widgets[8]->width()/2,widgets[8]->y()+widgets[8]->height()/2);
    QPoint B1(widgets[9]->x()+widgets[9]->width()/2,widgets[9]->y()+widgets[9]->height()/2);
    QPoint B2(widgets[10]->x()+widgets[10]->width()/2,widgets[10]->y()+widgets[10]->height()/2);
    QPoint B3(widgets[11]->x()+widgets[11]->width()/2,widgets[11]->y()+widgets[11]->height()/2);
    QPoint B4(widgets[12]->x()+widgets[12]->width()/2,widgets[12]->y()+widgets[12]->height()/2);
    QPoint B5(widgets[13]->x()+widgets[13]->width()/2,widgets[13]->y()+widgets[13]->height()/2);
    QPoint B6(widgets[14]->x()+widgets[14]->width()/2,widgets[14]->y()+widgets[14]->height()/2);

    QPoint C0(widgets[15]->x()+widgets[15]->width()/2,widgets[15]->y()+widgets[15]->height()/2);
    QPoint C1(widgets[16]->x()+widgets[16]->width()/2,widgets[16]->y()+widgets[16]->height()/2);

    QPoint C2(widgets[17]->x()+widgets[17]->width()/2,widgets[17]->y()+widgets[17]->height()/2);
    QPoint C3(widgets[18]->x()+widgets[18]->width()/2,widgets[18]->y()+widgets[18]->height()/2);

    QPoint C4(widgets[19]->x()+widgets[19]->width()/2,widgets[19]->y()+widgets[19]->height()/2);
    QPoint C5(widgets[20]->x()+widgets[20]->width()/2,widgets[20]->y()+widgets[20]->height()/2);

    QPoint C6(widgets[21]->x()+widgets[21]->width()/2,widgets[21]->y()+widgets[21]->height()/2);
    QPoint C7(widgets[22]->x()+widgets[22]->width()/2,widgets[22]->y()+widgets[22]->height()/2);

    QPoint Cx((C0+C2)/2);



//    QPoint w2(widgets[2]->pos().x()+widgets[2]->size().width()/2,widgets[2]->pos().y()+widgets[2]->size().height()/2);
//    QPoint w3(widgets[3]->pos().x()+widgets[3]->size().width()/2,widgets[3]->pos().y()+widgets[3]->size().height()/2);
    line.drawLine(A0,A1);
    line.drawLine(A2,A3);
    line.drawLine(A4,A5);
    line.drawLine(A6,A7);

    line.drawLine(A1,A4);
    line.drawLine(A3,A6);

    line.drawLine(B0,B1);
    line.drawLine(B1,B2);
    line.drawLine(B2,B3);
    line.drawLine(B3,B4);
    line.drawLine(B4,B5);
    line.drawLine(B5,B6);

    line.drawLine(A5,A7);
    line.drawLine(Ax,B0);

    line.drawLine(C0,C1);
    line.drawLine(C2,C3);
    line.drawLine(C4,C5);
    line.drawLine(C6,C7);

    line.drawLine(C1,C4);
    line.drawLine(C3,C6);

    line.drawLine(C0,C2);
    line.drawLine(B6,Cx);
    // evt->accept();
}

void MeasureSetupWindow::slotChangeIcon()
{
    int i = 1;
    if(widgets[i]->text()=="join"){
    widgets[i]->setIcon(QIcon(":/icons/join.PNG"));
    widgets[i]->setText("unjoin");
    }else{
        widgets[i]->setIcon(QIcon(":/icons/break.png"));
        widgets[i]->setText("join");
    }


}

void MeasureSetupWidget::mouseReleaseEvent(QMouseEvent *mouse)
{
    switch (mouse->button()) {
    case Qt::RightButton:
    {
        QMenu pPopup (this);
        QAction pAction1 ("Insert filter", this);
        QAction pAction2 ("Break", this);
        pPopup.addAction(&pAction1);
        pPopup.addAction(&pAction2);
        QAction* pItem = pPopup.exec(mouse->globalPos());
        if(pItem == &pAction1)
        {
            qDebug()<< "1";
        }
        else if(pItem == &pAction2)
        {
            qDebug()<< "2";
        }
    }
        break;
    default:
        break;
    }
    QToolButton::mouseReleaseEvent(mouse);
}

void MeasureSetupWindow::findwidgets()
{
    qDebug()<<"position "<<this->cursor().pos();
    for(unsigned int i= 0; i<23; i++)
    {
//int x = this->cursor().x;
//int y = this->cursor().y;
//int x_w = widget
//       }
        qDebug()<<"i = "<<i;

    }

}

void MeasureSetupWindow::slotShowfilter()
{
    FilterManagerWindow *Filter = new FilterManagerWindow(this);
    Filter->show();
}

void MeasureSetupWindow::slotShowTrace()
{
    TraceManager *Trace = new TraceManager(this);
    Trace->show();
}

void MeasureSetupWindow::slotShowhardware()
{
    HardwareInterface *Hardware = new HardwareInterface(this);
    Hardware->show();
}

MeasureSetupItemCommon::MeasureSetupItemCommon(MeasureSetupItemCommon *parent,E_MeasureSetupItemType itemType ,E_MeasureSetupBranch itemBranch )
{
    m_parentItem = parent;
    m_itemType = itemType ;
    m_itemBranch = itemBranch;
    m_JoinActive = true;
}

MeasureSetupItemCommon::~MeasureSetupItemCommon()
{
    //    foreach (MeasureSetupItemCommon* child, m_childItems) {
    //        if(child && child->getBranch() == getBranch()) delete child;
    //    }
    //    qDeleteAll(m_childItems);
    cleanWidget();
    cleanWindow();
}

MeasureSetupItemCommon *MeasureSetupItemCommon::child(int number)
{
    return m_childItems.value(number);
}

int MeasureSetupItemCommon::childCount() const
{
    return m_childItems.count();
}

int MeasureSetupItemCommon::childNumber() const
{
    if (m_parentItem)
        return m_parentItem->m_childItems.indexOf(const_cast<MeasureSetupItemCommon*>(this));
    return 0;
}

/*   [addChild]*/
/* [Me]-->[currentChild]*/
/*==>[Me]-->[currentChild]*/
/*      |-->[insertChild] */
bool MeasureSetupItemCommon::addChildren(int position, MeasureSetupItemCommon * child)
{
    if (position < 0 || position > m_childItems.size() || child == NULL)
        return false;
    m_childItems.insert(position, child);
    return true;
}

/*   [insertChild]*/
/* [Me]-->[currentChild]*/
/*==>[Me]-->[insertChild]-->[currentChild]*/
bool MeasureSetupItemCommon::insertChildren(int position, MeasureSetupItemCommon * child)
{
    if (position < 0 || position > m_childItems.size() || child == NULL)
        return false;
    MeasureSetupItemCommon * currentChild;
    currentChild = m_childItems.takeAt(position);
    m_childItems.removeAt(position);
    child->m_childItems.insert(0, currentChild);
    m_childItems.insert(position,child);
    currentChild->m_parentItem = child;
    return true;
}

MeasureSetupItemCommon *MeasureSetupItemCommon::parent()
{
    return m_parentItem;
}

bool MeasureSetupItemCommon::removeChildren(MeasureSetupItemCommon * child)
{
    if ( child == NULL )
        return false;
    return  m_childItems.removeOne(child);
}

void MeasureSetupItemCommon::refreshConnection()
{
    disconnect(this,SIGNAL(sendData()));
    foreach (MeasureSetupItemCommon * child, m_childItems) {
        if(child){
            connect(this,SIGNAL(sendData(MessageCommon*)),child,SLOT(rcvData(MessageCommon*)));
        }
    }
}

QJsonValue MeasureSetupItemCommon::saveDocument(QJsonArray & parent )
{
    return QJsonValue();
}

MeasureSetupItemJoin:: MeasureSetupItemJoin(MeasureSetupItemCommon *parent ):
    MeasureSetupItemCommon(parent,E_MeasureSetupItemType_Join)
{

}

MeasureSetupItemJoin::~MeasureSetupItemJoin()
{

}

MeasureSetupItemFilter:: MeasureSetupItemFilter(MeasureSetupItemCommon *parent ):
    MeasureSetupItemCommon(parent,E_MeasureSetupItemType_Filter)
{

}

MeasureSetupItemFilter::~MeasureSetupItemFilter()
{

}
