#include <QtGui>
#include "tracemanager.h"
#include "ui_tracemanager.h"
#include <tracetreemodel.h>
#include<QStringList>
#include <QTreeView>
TraceManager::TraceManager(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::TraceManager)
{
    ui->setupUi(this);
    setupItems();

    setCentralWidget(ui->treeView);
    setWindowTitle(tr("Trace All"));
    setWindowIcon(QPixmap(":/icons/logo.png"));
}

TraceManager::~TraceManager()
{
    delete ui;
}

void TraceManager::setupItems()
{
    QStringList items;
    items << tr("17.025413\t1\t11\tMsgSine\tTx\t8\t3E 14 49 16 00 00 00 00")
          << tr(" SineJitter\t \t-0.4295 Volts\t[1649]")
          << tr(" Sine\t \t-0.4818 Volts\t[143E]")
          << tr("17.061320\t1\t10\tMsgPeak\tTx\t4\t00 00 00 00")
          << tr(" Peak2\t \t0\t[0]")
          << tr(" Peak1\t \t0\t[0]")
          << tr("17.01232\t1\t12\tMsgSparse\tTx\t8\t3F 48 00 00 00 00 00 00")
          << tr(" Sine\t \t0.8495 Volts\t[483F]");
    TraceTreeModel *model = new TraceTreeModel(items, this);

    QModelIndex index = model->index(0, 0, QModelIndex());
 //   model->insertRows(2, 3, index);
    index = model->index(0, 0, QModelIndex());
    index = model->index(2, 0, index);
  //  model->removeRows(1, 3, index.parent());
    model->setData(index, QVariant("17.025413"));
    ui->treeView->setModel(model);

}
